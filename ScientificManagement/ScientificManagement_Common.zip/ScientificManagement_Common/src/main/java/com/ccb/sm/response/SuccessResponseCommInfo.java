package com.ccb.sm.response;

import java.util.UUID;

public class SuccessResponseCommInfo 
{
	private String token;

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

}
