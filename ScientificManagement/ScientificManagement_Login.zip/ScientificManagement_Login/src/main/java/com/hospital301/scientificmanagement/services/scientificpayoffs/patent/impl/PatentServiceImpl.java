package com.hospital301.scientificmanagement.services.scientificpayoffs.patent.impl;

import org.springframework.stereotype.Service;

import com.hospital301.scientificmanagement.services.BaseServiceImpl;
import com.hospital301.scientificmanagement.services.scientificpayoffs.patent.PatentService;

@Service
public class PatentServiceImpl extends BaseServiceImpl  implements PatentService
{
	
}
 