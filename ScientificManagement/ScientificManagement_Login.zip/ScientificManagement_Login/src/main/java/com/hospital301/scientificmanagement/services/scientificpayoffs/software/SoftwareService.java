package com.hospital301.scientificmanagement.services.scientificpayoffs.software;

public interface SoftwareService 
{
}
