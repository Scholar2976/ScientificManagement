package com.hospital301.scientificmanagement.services.scientificpayoffs.reward;

import com.ccb.sm.entities.ProjectReward;
import com.hospital301.scientificmanagement.services.BaseServieInterface;;

public interface RewardService 
{
//	public Map QueryResultInfo(Map<String,Object> map);
	
//	public Object insert(Object projectResult);
}
