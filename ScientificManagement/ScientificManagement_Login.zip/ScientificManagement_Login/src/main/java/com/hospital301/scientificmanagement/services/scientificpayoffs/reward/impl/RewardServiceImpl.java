package com.hospital301.scientificmanagement.services.scientificpayoffs.reward.impl;

import org.springframework.stereotype.Service;
import com.hospital301.scientificmanagement.services.BaseServiceImpl;
import com.hospital301.scientificmanagement.services.scientificpayoffs.reward.RewardService;

@Service
public class RewardServiceImpl extends BaseServiceImpl implements RewardService 
{
}
