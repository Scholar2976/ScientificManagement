package com.hospital301.scientificmanagement.services.scientificpayoffs.software.impl;

import com.hospital301.scientificmanagement.services.BaseServiceImpl;
import com.hospital301.scientificmanagement.services.scientificpayoffs.software.SoftwareService;

public class SoftwareServiceImpl extends BaseServiceImpl  implements SoftwareService
{
	
}
