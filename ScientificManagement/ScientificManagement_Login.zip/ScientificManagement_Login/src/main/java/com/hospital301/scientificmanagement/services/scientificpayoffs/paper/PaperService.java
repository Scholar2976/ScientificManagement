package com.hospital301.scientificmanagement.services.scientificpayoffs.paper;

import java.util.List;
import java.util.Map;


import com.ccb.sm.entities.ProjectPaperJoinMember;
import com.hospital301.scientificmanagement.services.BaseServieInterface;

public interface PaperService 
{
	public Map QueryTableInfo(Map<String, Object> map);
}
