package com.hospital301.scientificmanagement.dao.BaseMapper;

import org.apache.ibatis.annotations.Mapper;
import com.ccb.sm.baseDao.BaseMapper.BaseMapper;

@Mapper
public interface FatherMapper extends BaseMapper
{
	
//	public List<Map<String,Object>> QueryByUser(@Param("tableName") String tableName , @Param("conditionMap")Map<String,Object> conditionMap);
//	
//	public List<Map<String,Object>> QueryByOrg(@Param("tableName") String tableName , @Param("conditionMap") Map<String,Object> conditionMap);
}
