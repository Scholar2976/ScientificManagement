package com.hospital301.scientificmanagement.services.user;

import java.util.Map;

import com.ccb.sm.entities.User;

public interface UserService 
{
	public Object searchUser(String username);
}
