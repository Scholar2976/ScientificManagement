package com.hospital301.scientificmanagement.dao.parameter;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ParameterDao 
{
	
}
