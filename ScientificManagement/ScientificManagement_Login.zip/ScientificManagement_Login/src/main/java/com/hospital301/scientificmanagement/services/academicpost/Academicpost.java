package com.hospital301.scientificmanagement.services.academicpost;

import java.util.Map;

public interface Academicpost
{
	public Boolean logicDelete(Map<String,Object> map);
}
