package com.hospital301.scientificmanagement.dao.scientificpayoffs.software;

import org.apache.ibatis.annotations.Mapper;

import com.hospital301.scientificmanagement.dao.BaseMapper.FatherMapper;

@Mapper
public interface ProjectSoftwareMapper extends FatherMapper{

}
