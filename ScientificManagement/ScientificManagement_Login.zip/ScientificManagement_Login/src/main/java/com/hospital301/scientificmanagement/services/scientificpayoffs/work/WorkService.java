package com.hospital301.scientificmanagement.services.scientificpayoffs.work;

import java.util.Map;

public interface WorkService
{
	public Map QueryTableInfo(Map<String, Object> map);
}
