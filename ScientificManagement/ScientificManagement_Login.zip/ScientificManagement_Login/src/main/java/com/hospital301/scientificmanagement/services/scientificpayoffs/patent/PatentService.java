package com.hospital301.scientificmanagement.services.scientificpayoffs.patent;

import java.util.Map;

public interface PatentService
{
}
